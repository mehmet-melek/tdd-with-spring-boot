package com.ykb.architecture.testservices.automationdatacreator.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ykb.architecture.testservices.automationdatacreator.model.Query;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

@SpringBootTest(webEnvironment = RANDOM_PORT)
@TestInstance(TestInstance.Lifecycle.PER_CLASS) //used for non-static before method
public class ComponentTest {

    private final static String BASE_URI = "http://localhost";

    @LocalServerPort
    private int port;

    private Response response;
    private RequestSpecification requestSpecification;

    @BeforeAll
    void configureRestAssured() {
        RestAssured.baseURI = BASE_URI;
        RestAssured.port = port;
    }

    @BeforeEach
    void beforeEachTest() {
        response = null;
        requestSpecification = RestAssured.given();
    }

    @Test
    void whenGetBooks_shouldReturnAllBooks() throws InterruptedException, JsonProcessingException {
        Query query = Query.builder()
                .artifactId("automation-data-creator")
                .database("CBSLIVE")
                .schema("STA")
                .sqlQuery("select * from abc where x='y'").build();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(query);

        response = requestSpecification
                .header("Content-Type", "application/json")
                .body(json).when().post("/data/execute-query");
        response.then().assertThat()
                .statusCode(equalTo(201))
                .body("id", is(1))
                .body("schema", equalTo("STA"));
    }


}
