package com.ykb.architecture.testservices.automationdatacreator.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ykb.architecture.testservices.automationdatacreator.model.Query;
import com.ykb.architecture.testservices.automationdatacreator.service.DataService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(DataController.class)
public class DataControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DataService dataService;


    @Test
    void ExecutionQueryTest() throws Exception {
        Query query = Query.builder()
                .artifactId("automation-data-creator")
                .database("CBSLIVE")
                .schema("STA")
                .sqlQuery("select * from abc where x='y'").build();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(query);

        mockMvc.perform(MockMvcRequestBuilders.post("/data/execute-query")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("id").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("status").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("result").exists());
    }

    @Test
    void executeUpdateTest() throws Exception {
        Query query = new Query();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(query);

        mockMvc.perform(MockMvcRequestBuilders.post("/data/execute-update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("id").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("status").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("result").exists());
        ;
    }

}
