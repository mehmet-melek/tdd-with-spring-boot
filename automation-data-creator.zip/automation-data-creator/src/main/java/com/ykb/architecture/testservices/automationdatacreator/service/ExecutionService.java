package com.ykb.architecture.testservices.automationdatacreator.service;

import com.ykb.architecture.testservices.automationdatacreator.mapper.ExecutionMapper;
import com.ykb.architecture.testservices.automationdatacreator.model.Execution;
import com.ykb.architecture.testservices.automationdatacreator.model.ExecutionStatus;
import com.ykb.architecture.testservices.automationdatacreator.model.Query;
import com.ykb.architecture.testservices.automationdatacreator.repository.ExecutionRepository;
import org.springframework.stereotype.Service;

@Service
public class ExecutionService {

    private final ExecutionRepository executionRepository;
    private final ExecutionMapper executionMapper;

    public ExecutionService(ExecutionRepository executionRepository, ExecutionMapper executionMapper) {
        this.executionRepository = executionRepository;
        this.executionMapper = executionMapper;
    }

    public Execution getExecution(Long executionId) {
        return executionRepository.findById(executionId).orElseThrow();
    }

    public Execution getExecutionByStatus(String status) {
        return executionRepository.findByStatus(status).orElseThrow();
    }

    public Execution startQueryExecution(Query query) {

        Execution execution = executionMapper.queryToExecution(query);
        execution.setStatus(String.valueOf(ExecutionStatus.STARTED));
        return executionRepository.save(execution);
    }

    public Execution startUpdateExecution(Query query) {
        Execution execution = executionMapper.queryToExecution(query);
        execution.setStatus(String.valueOf(ExecutionStatus.STARTED));
        return executionRepository.save(execution);
    }
}
