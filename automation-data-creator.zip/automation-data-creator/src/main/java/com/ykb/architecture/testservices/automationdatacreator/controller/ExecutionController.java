package com.ykb.architecture.testservices.automationdatacreator.controller;

import com.ykb.architecture.testservices.automationdatacreator.model.Execution;
import com.ykb.architecture.testservices.automationdatacreator.service.ExecutionService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/executions")
public class ExecutionController {

    private final ExecutionService executionService;

    public ExecutionController(ExecutionService executionService) {
        this.executionService = executionService;
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public Execution getExecution(@RequestParam("id") Long id){
        return executionService.getExecution(id);
    }

    @GetMapping("/status")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public Execution getExecutionByStatus(@RequestParam("status") String status){
        return executionService.getExecutionByStatus(status);
    }



}
