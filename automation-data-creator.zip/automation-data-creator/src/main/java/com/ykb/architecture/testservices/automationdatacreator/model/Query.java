package com.ykb.architecture.testservices.automationdatacreator.model;


import lombok.*;

import javax.persistence.Lob;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Query {

    private String database;
    private String schema;
    private String sqlQuery;

    private String artifactId;


}
