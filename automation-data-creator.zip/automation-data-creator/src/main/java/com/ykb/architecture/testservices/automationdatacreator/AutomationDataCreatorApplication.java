package com.ykb.architecture.testservices.automationdatacreator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
//@ComponentScan(basePackages = {"com.ykb.architecture.testservices.automationdatacreator","com.ykb.architecture.testservices.automationdatacreator.mapper"})
public class AutomationDataCreatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(AutomationDataCreatorApplication.class, args);
    }

}
