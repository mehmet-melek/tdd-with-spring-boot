package com.ykb.architecture.testservices.automationdatacreator.repository;


import com.ykb.architecture.testservices.automationdatacreator.model.Execution;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ExecutionRepository extends JpaRepository<Execution, Long> {

    Optional<Execution> findByStatus(String status);

}
