package com.ykb.architecture.testservices.automationdatacreator.model;


import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
public class Execution {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private long id;
    private String artifactId;
    private String database;
    private String schema;
    private String sqlQuery;
    private String status;
    private String result;

}
