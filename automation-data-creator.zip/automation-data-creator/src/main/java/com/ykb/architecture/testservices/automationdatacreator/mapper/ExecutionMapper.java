package com.ykb.architecture.testservices.automationdatacreator.mapper;

import com.ykb.architecture.testservices.automationdatacreator.model.Execution;
import com.ykb.architecture.testservices.automationdatacreator.model.Query;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

@Mapper(componentModel = "spring")
@Component
public interface ExecutionMapper {

    ExecutionMapper INSTANCE = Mappers.getMapper(ExecutionMapper.class);
    Execution queryToExecution(Query query);
}
