package com.ykb.architecture.testservices.automationdatacreator.controller;


import com.ykb.architecture.testservices.automationdatacreator.model.Query;
import com.ykb.architecture.testservices.automationdatacreator.model.Execution;
import com.ykb.architecture.testservices.automationdatacreator.service.DataService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/data")
public class DataController {


  private final DataService dataService;

  public DataController(DataService dataService) {
    this.dataService = dataService;
  }

  @PostMapping("/execute-query")
  @ResponseStatus(HttpStatus.CREATED)
  @ResponseBody
  public Execution dataSelect(@RequestBody Query query) {
    return dataService.executeSelect(query);
  }

  @PostMapping("/execute-update")
  @ResponseStatus(HttpStatus.CREATED)
  @ResponseBody
  public Execution dataUpdate(@RequestBody Query query) {
    dataService.executeUpdate(query);
    return null;

  }

}
