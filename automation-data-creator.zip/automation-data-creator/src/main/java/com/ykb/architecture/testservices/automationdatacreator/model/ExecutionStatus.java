package com.ykb.architecture.testservices.automationdatacreator.model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

public enum ExecutionStatus {
    STARTED,
    COMPLETED,
    FAILED;
}
