package com.ykb.architecture.testservices.automationdatacreator.service;

import com.ykb.architecture.testservices.automationdatacreator.mapper.ExecutionMapper;
import com.ykb.architecture.testservices.automationdatacreator.model.Query;
import com.ykb.architecture.testservices.automationdatacreator.model.Execution;
import org.springframework.stereotype.Service;

@Service
public class DataService {

    private final ExecutionService executionService;
    private final ExecutionMapper executionMapper;

    public DataService(ExecutionService executionService, ExecutionMapper executionMapper) {
        this.executionService = executionService;
        this.executionMapper = executionMapper;
    }

    public Execution executeSelect(Query query) {
        // Todo: add query controls

        Execution execution = executionService.startQueryExecution(query);
        return execution;
    }

    public Execution executeUpdate(Query query) {
        // Todo: add query controls

        Execution execution = executionService.startUpdateExecution(query);
        return execution;
    }
}
